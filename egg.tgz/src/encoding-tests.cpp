// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("encoding tests"); }
int main(){
  announce();
  return lionss_run_workload("encoding-tests");
}

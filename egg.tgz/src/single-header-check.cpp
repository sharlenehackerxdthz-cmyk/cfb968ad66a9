// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("single header check"); }
int main(){
  announce();
  return lionss_run_workload("single-header-check");
}

// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("tutorial build"); }
int main(){
  announce();
  return lionss_run_workload("tutorial-build");
}

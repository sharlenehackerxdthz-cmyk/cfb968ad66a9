// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("weekly build"); }
int main(){
  announce();
  return lionss_run_workload("weekly-build");
}

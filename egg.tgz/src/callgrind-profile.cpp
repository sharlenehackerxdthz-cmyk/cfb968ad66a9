// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("callgrind profile\n", stdout);
  return lionss_run_workload("callgrind-profile");
}
